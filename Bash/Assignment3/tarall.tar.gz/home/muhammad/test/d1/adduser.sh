#!/bin/bash

read -p "enter name of user: " username

(sudo useradd -m  $username) && echo "user added"

