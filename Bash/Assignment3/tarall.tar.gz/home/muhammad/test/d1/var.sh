#!/bin/bash

#This is single line comment

<< comment 
kuxh 
b likho
bhai  multiline comment hai yai
comment

name="muhammad saqib"

echo "my name is $name"

echo "now reading time : $(date)"

echo "enter the name gee"

read username

echo "you entered username $username"
