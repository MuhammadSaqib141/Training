#!/bin/bash

echo "my first script"
