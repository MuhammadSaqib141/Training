#!/bin/bash

age=15
if [ $age -gt 10 ]; then
	echo "value is greater"
fi
